<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class AccueilController extends AbstractController
{
    #[Route('/accueil', name: 'Accueil')]
    public function bienvenue(): Response
    {
        return $this->render('accueil.html.twig');
    }

    
    #[Route('/seances', name: 'Seance')]
    public function Seance(): Response 
    {
        return $this->render('seances.html.twig');
    }

    #[Route('/films', name: 'films')]
    public function films(): Response 
    {
        return $this->render('films.html.twig');
    }

    #[Route('/offres', name: 'Offres')]
    public function offres(): Response 
    {
        return $this->render('offres.html.twig');
    }
   
    
}
